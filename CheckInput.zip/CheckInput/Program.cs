﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CheckInput
{
    internal class Program
    {
        static void Main(string[] args)
        {
            inputChecker CheckIt = new inputChecker();

            Console.WriteLine("Please enter a Value");
            
            CheckIt.Input = Console.ReadLine();

            Console.WriteLine("Did you enter \n 1.String \n 2.Integer \n 3.Boolean");

            string type = Console.ReadLine();

            if(Int32.TryParse( type, out int typeint))
            {
                //Console.WriteLine(typeint);

                if (typeint == 2)
                {
                    if(Int32.TryParse(CheckIt.Input, out int input_1))
                    {
                        Console.WriteLine("Your input {0} is of type integer", input_1);
                    }
                    else
                    {
                        Console.WriteLine("Input is not a valid integer");
                    }
                }
                else if (typeint == 3)
                {
                    if(Boolean.TryParse(CheckIt.Input, out bool input_2))
                    {
                        Console.WriteLine("Your input {0} is of type Boolean", input_2);
                    }
                    else
                    {
                        Console.WriteLine("Input is not a valid Boolean");
                    }
                }    
                else if (typeint == 1)
                {
                    if(CheckIt.Input.Any(char.IsDigit))
                    {
                        Console.WriteLine("Input is not a valid String");
                    }
                    else
                    {
                        Console.WriteLine("Your input of {0}, is a string",CheckIt.Input);
                    }
                }
            }

            else
            {
                Console.WriteLine("Could not be Parsed");
            }
            


            Console.ReadKey(); 







        }
    }
}
