﻿using System;


namespace NumberGuesser1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            String appName = "Number Guesser";
            String appVersion = "1.0.0";
            String appAuthor = "Seth Moffett";
            // Change Console Text color
            Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.Black;
            Console.WriteLine("{0}: Version {1} : Birthed by {2}", appName, appVersion, appAuthor);
            // Change Back
            Console.ResetColor();

            // Get User Input
            Console.WriteLine("What is your Name?");

            String input = Console.ReadLine();

            Console.WriteLine("Hello {0}, Let's Play A Game... ", input);

            Random random = new Random();
            

                //int CorrectNumber = 7;

                int CorrectNumber = random.Next(1, 10);

            Console.WriteLine("Guess a Number from 1 to 10... ");



            string Input = Console.ReadLine();

            if (!int.TryParse(Input, out int Guess))
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("Not a number Bro... Beep Beep Boop");
                Console.ResetColor();

            }

            // int Guess = int.Parse(Input);

            else if (Guess == CorrectNumber)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("Good Job... ");
                //flag = 1;
                Console.ResetColor();
                
                Console.WriteLine("Would you like to play again?([Y or N])");
                int flag = 0;
                while (flag == 0)
                {
                    string answer = Console.ReadLine().ToUpper();
                    if (answer == "Y")
                    {

                        flag = 1;
                        continue;
                    }
                    else if (answer == "N")
                    {
                        return;
                    }
                    else
                    {
                        Console.WriteLine("Not an N or Y homie... ");
                        continue;
                    }
                }
            }
            else if (Guess < 1 || Guess > 10)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Yo do you know how to read instructions?");
                Console.ResetColor();
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Magenta;
                Console.WriteLine("Nope... LOL... ");
                Console.ResetColor();
            }
        

            Console.WriteLine("Press Enter To Continue... ");
            Console.ReadLine();

        }
        
    }
}
