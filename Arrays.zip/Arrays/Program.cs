﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Arrays
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string[] friends = new string[] { "Brandon", "Bryant", "Marlix", "Lixmar", "Roku" }; 


            foreach(string name in friends)
            {
                Console.WriteLine("Hello {0}",name);
            }



            Console.ReadKey();
        }
    }
}
