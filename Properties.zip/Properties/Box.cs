﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Properties
{
    class Box
    {
        //private string color = "white";
        private int length = 3;
        private int height;
        //public int width;
        private int volume;


        public int FrontSurface
            {
            get { return this.length * Height; }
            }

        public int Width { get; set; }

        public int Volume
        {
            get 
            { 
                return this.length * this.Width * this.Height; 
            }
            
        }


        public int Height
        {
            get 
            { 
                return height; 
            }
            set
            {
                if (value < 0)
                {
                    height = -value;
                }
                else
                {
                    height = value;
                }
            }
        }


        public void SetLength(int length)
        {
            if(length < 0)
            {
                throw new Exception("length should be higher than 0");
            }
            this.length = length;
        }

        public int GetLength()
        {
            return length;
        }


        public Box(int length, int height, int width)
        {
            this.length = length;
            this.height = height;
            Width = width;
        }

       

        public void DisplayInfo()
        {
            Console.WriteLine("Length is {0}, and height is {1} and width is {2}, so the volume is {3}", 
                length, Height, Width, Volume);

            Console.ReadKey();
        }
    }
}
