﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Properties
{
    class Program
    {


        static void Main(string[] args)
        {
            Box box = new Box(3, 4, 5);

            Console.WriteLine("Box width is " + box.Width);

            Console.WriteLine("Front Surface Area is {0}", box.FrontSurface);

            Console.WriteLine("Box volume is " + box.Volume);
            box.Width = 10;

            box.DisplayInfo();

        }
    }
}
